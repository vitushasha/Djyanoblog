SECRET_KEY = 'django-insecure-2t!+wqu_8_qj6=v-ckd^%bgkn4e8sbi3zg8l_xjdj5pcudej1-'

GITHUB_KEY = 'Ov23lidgX38KHikzsikE'
GITHUB_SECRET = 'd2971992024d6169520068c1b9e06f7aea87e274'


GOOGLE_KEY = '231029148642-fefhnnjnhaojc47s4rqfcph41uia2lcv.apps.googleusercontent.com'
GOOGLE_SECRET = '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'